#####

HeardBox Read Me.

This is an early build of a python interface designed to incorporate UniprotKB Functions, pubMed with Microsoft Excel Office.
Created for the purpose of investigation of proteomic datasets.